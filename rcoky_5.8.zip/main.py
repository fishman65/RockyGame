import pygame
import random
from player import Player1
from bg import Background
# set up pygame modules
pygame.init()
pygame.font.init()
size = (1600, 960)
screen = pygame.display.set_mode(size)
p1 = Player1(200,200)
bg = Background(0,0)

# render the text for later

# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
# -------- Main Program Loop -----------
clock = pygame.time.Clock()
frame = 0
while run:
    clock.tick(60)
    # --- Main event loop

    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE]:
        p1.punch(10)

    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False
        screen.blit(bg.image, bg.rect)
        screen.blit(p1.image, p1.rect)
    pygame.display.update()
    frame += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()

