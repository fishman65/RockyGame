
import pygame
import time
class Player1:
    def __init__(self,x,y):

        self.x = x
        self.y = y
        self.image = pygame.image.load('rcoky.png')
        self.image_size = self.image.get_size()
        self.image_list = ['rcoky.png', 'box_punch.png']
        self.rescale_image(self.image)
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0],self.image_size[1])

    def rescale_image(self, image):
        self.image_size = self.image.get_size()
        scale_size = (self.image_size[0] * .1, self.image_size[1] * .1)
        self.image = pygame.transform.scale(self.image, scale_size)

    def punch(self, energy):
        self.start_t = time.time()
        self.energy = energy
        self.punch = True
        self.new_t = time.time()
        if energy > 1 and self.punch:
            self.image = pygame.image.load(self.image_list[1])
            while self.new_t - self.start_t < 5:
                self.new_t = time.time()
            self.image = pygame.image.load(self.image_list[0])
            print('2  ')
        self.rescale_image(self.image)
