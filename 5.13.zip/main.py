import time

import pygame
import random
from player import Player1
from bg import Background
# set up pygame modules
pygame.init()
pygame.font.init()
size = (1600, 960)
screen = pygame.display.set_mode(size)
p1 = Player1(200,200)
bg = Background(0,0)
time_a = time.time()
# render the text for later
was_punch = False
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
# -------- Main Program Loop -----------
clock = pygame.time.Clock()
frame = 0
while run:
    clock.tick(60)

    # --- Main event loop

    keys = pygame.key.get_pressed()
    time_b = time.time()
    if keys[pygame.K_SPACE]:
        was_punch = True
    if keys[pygame.K_RIGHT]:
        p1.x += 3
        print('top')

        # switch the player image and record the time the image was switched

    if frame % 30 != 0 and was_punch:
        p1.do_punch(10, True)
    elif was_punch and frame % 30 == 0:
        p1.do_punch(10,False)
        print('heloo')
        was_punch = False

    # two seconds after the time was recorded, switch the image back

    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

    screen.fill((0,0,0))
    screen.blit(bg.image, bg.rect)
    screen.blit(p1.image, p1.rect)
    pygame.display.update()
    frame += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()

