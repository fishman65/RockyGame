import pygame
import time
class Creed1:
    def __init__(self,x,y,energy):

        self.x = x
        self.y = y
        self.image = pygame.image.load('Screenshot_2024-05-16_092252-removebg-preview.png')
        self.image_size = self.image.get_size()
        self.image_list = ['Screenshot_2024-05-16_092252-removebg-preview.png', 'creed.png']
        self.rescale_image(self.image,1,1)
        self.energy = energy
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0],self.image_size[1])
        self.punch = False
        self.dis = 8
        self.health = 100
    def rescale_image(self, image,a,b):
        self.image_size = self.image.get_size()
        scale_size = (self.image_size[0] * a, self.image_size[1] * b)
        self.image = pygame.transform.scale(self.image, scale_size)

    def do_punch(self, energy,punch):

        self.punch = punch
        self.energy -= 1


        if energy > 1 and self.punch:
            self.image = pygame.image.load(self.image_list[1])
            self.rescale_image(self.image,.6,.6)
            print('2')
        elif not self.punch:
            self.image = pygame.image.load(self.image_list[0])
            print('23')
            self.rescale_image(self.image,1 ,1)
    def move(self,direction):
        if direction =='L':
            self.x = self.x - self.dis
            print(self.x)
        if direction == 'R':
            self.x = self.x + self.dis
            print(self.x)
        if direction == 'U':
            self.y -= 5
        if direction == 'D':
            self.y += 5
        self.rect = pygame.Rect(self.x,self.y,self.image_size[0],self.image_size[1])