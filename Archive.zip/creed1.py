import pygame
import time
class Creed1:
    def __init__(self,x,y,energy):

        self.x = x
        self.y = y

        self.energy = energy
        self.rect = pygame.Rect(self.x, self.y,64,64)
        self.punch = False
        self.dis = 8
        self.health = 100
    def rescale_image(self, image,a,b):
        self.image_size = self.image.get_size()
        scale_size = (self.image_size[0] * a, self.image_size[1] * b)
        self.image = pygame.transform.scale(self.image, scale_size)

    def do_punch(self, energy,punch):

        self.punch = punch
        self.energy -= 1


        if energy > 1 and self.punch:
            self.rect = pygame.Rect(self.x, self.y, 100, 100)
            print('2')
        elif not self.punch:

            print('23')

    def move(self,direction):
        if direction =='L':
            self.x = self.x - self.dis
            print(self.x)
        if direction == 'R':
            self.x = self.x + self.dis
            print(self.x)
        if direction == 'U':
            self.y -= 5
        if direction == 'D':
            self.y += 5
        self.rect = pygame.Rect(self.x,self.y,64,64)