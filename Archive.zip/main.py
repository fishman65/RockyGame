import time

import pygame
import random
game_sstart =  False
one_time_3 = True
p1_win = False
p2_win = False
import spritesheet
from player import Player1
from bg import Background
from creed1 import Creed1
from spritesheet import Spritesheet
# set up pygame modules
health1 = 100
health2 = 100
one_time_punch = True
pygame.init()
was_punch_D = False
facingd = 'L'
upcut = False
pygame.font.init()
my_font = pygame.font.SysFont('Arial',20)
my_font2 = pygame.font.SysFont('Arial',16)
one_time = False
one_time_2 = True
one_time_2d = True
one_timed = False
right = False
left = False
facing = 'L'
size = (1600, 960)
screen = pygame.display.set_mode(size)
p1 = Player1(200,200,20)
bg = Background(0,0)
p1energy = 20
p2energy = 20
p2 = Creed1(200,200,20)
time_a = time.time()
sprite_sheet_image = pygame.image.load('spritesheet (3).png').convert_alpha()
sprite_sheet = spritesheet.Spritesheet(sprite_sheet_image)
sprite_sheet_image_d = pygame.image.load('creed.png').convert_alpha()
sprite_sheet_d = spritesheet.Spritesheet(sprite_sheet_image_d)
black = (0,0,0)
current_time_2 = 0
#animation list
animation_list = []
animation_steps = [19,18,7,18,7]
action = 1
last_update = pygame.time.get_ticks()
punch_time = pygame.time.get_ticks()
animation_cooldown = 20
frame_a = 0
step_counter = 0
for animation in animation_steps:
    temp_list = []
    for _ in range(animation):
        temp_list.append(sprite_sheet.get_image(step_counter, 64, 64, black))
        step_counter += 1
    animation_list.append(temp_list)

animation_listd = []
animation_stepsd = [7,7,18,18]
actiond = 1
last_updated = pygame.time.get_ticks()
punch_timed = pygame.time.get_ticks()
animation_cooldownd = 20
frame_ad = 0
step_counterd = 0
for animation in animation_stepsd:
    temp_listd = []
    for _ in range(animation):
        temp_listd.append(sprite_sheet_d.get_image(step_counterd, 64, 64, black))
        step_counterd += 1
    animation_listd.append(temp_listd)

# render the text for later
p1_health = my_font.render('Rocky Balboa Health:' +str(health1),True,(255,255,255))
p2_health = my_font.render('Ivan Drago Health:' +str(health2),True,(255,255,255))
p1_energy = my_font.render('Rocky Balboa Enegry:' + str(p1energy),True,(255,255,255))
p2_energy = my_font.render('Ivan Drago Enegry:' + str(p2energy),True,(255,255,255))
welcome = my_font2.render('Welcome to the rocky fighting game, use wasd and q for punch as ivan drago, and arrows and space to play as rocky, click 1 to start!',True,(255,255,255))
win_message = my_font.render('Congrats, Rocky won the Game',True(255,255,255))
win_messageD = my_font.render('Congrats, Ivan won the Game',True(255,255,255))
was_punch = False
was_punch_C = False
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
# -------- Main Program Loop -----------
clock = pygame.time.Clock()
frame = 0
while run:
    clock.tick(60)
    if frame % 120 == 0:
        p1energy += 1
        p2energy += 1


        p1_energy = my_font.render('Rocky Balboa Enegry:' + str(p1energy), True, (255, 255, 255))
        p2_energy = my_font.render('Ivan Drago Enegry:' + str(p2energy), True, (255, 255, 255))
    p1_health = my_font.render('Rocky Balboa Health:' + str(health1), True, (255, 255, 255))
    p2_health = my_font.render('Ivan Drago Health:' + str(health2), True, (255, 255, 255))
    # --- Main event loop

    keys = pygame.key.get_pressed()
    time_b = time.time()
    if keys[pygame.K_SPACE]:
        was_punch = True
        was_punch = True


    if keys[pygame.K_1]:
        game_sstart = True
    if keys[pygame.K_q]:
        was_punch_C = True
    if keys[pygame.K_LEFT]:
        p1.move('L')
        facing = 'L'

    if keys[pygame.K_RIGHT]:
        p1.move('R')
        facing = 'R'
    if keys[pygame.K_UP]:
        p1.move('U')
        facing = 'U'

    if keys[pygame.K_DOWN]:
        p1.move('D')
        facing = 'D'
    if keys[pygame.K_RETURN]:
        upcut = True
    if keys[pygame.K_q]:
        was_punch_D = True
    if keys[pygame.K_w]:
        p2.move('U')
        facingd = 'U'
    if keys[pygame.K_s]:
        p2.move('D')
        facingd = 'D'
    if keys[pygame.K_a]:
        p2.move('L')
        facingd = 'L'

    if keys[pygame.K_d]:
        p2.move('R')
        facingd = 'R'
    #COLLISIONS

    if p1.rect.colliderect(p2.rect) and was_punch and one_time:

        health2 -= 5
        p1energy -= 1

    if p2.rect.colliderect(p1.rect) and was_punch_D and one_timed:

        health1 -= 5
        p2energy -= 1
        # switch theplayer image and record the time the image was switched
    current_time = pygame.time.get_ticks()
    current_timed = pygame.time.get_ticks()
    current_time_2 = pygame.time.get_ticks()


    new_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame_a += 1
        last_update = current_time
        if frame_a >= len(animation_list[action]):
            frame_a = 0
    if current_timed - last_updated >= animation_cooldownd:
        frame_ad += 1
        last_updated = current_timed
        if frame_ad >= len(animation_listd[actiond]):
            frame_ad = 0


    #if frame % 30 != 0 and was_punch_C:

    #elif was_punch_C and frame % 30 == 0:
#
   #     p2.energy -= 1
    #    p2_health = my_font.render(str(p2.energy), True, (255, 255, 255))

   #     print('heloo')
    #    was_punch_C = False


    # two seconds after the time was recorded, switch the image back

    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False
    #update animation

    if was_punch:
        if facing == 'R':
            action = 3
        elif facing == 'L':
            action = 0
        else:
            print('2')
        if one_time:
            frame_a = 0
            one_time = False
            one_time_2 = True
            punch_time = current_time_2
        if current_time_2 - punch_time >= 400:
            was_punch = False

            punch_time = current_time_2
    elif was_punch == False and upcut == False:

        if facing == 'L':

            action = 4
        elif facing == 'R':
            action = 2

        if one_time_2:
            one_time = True
            one_time_2 = False
            frame_a = 0


    else:

        if facing == 'L':
            action = 4
        if facing == 'R':
            action = 1
    print(p1.x)
    print(p1.y)
    #cdrag 395,600 190 ,1095
    if p1.x < 400:
        p1.x = 420
    if p1.x > 1095:
        p1.x = 1050
    if p1.y < 190:
        p1.y = 200
    if p1.y > 600:
        p1.y = 580

    if p2.x < 400:
        p2.x = 420
    if p2.x > 1095:
        p2.x = 1050
    if p2.y < 190:
        p2.y = 200
    if p2.y > 600:
        p2.y = 580

    if was_punch_D:
        if facingd == 'R':
            actiond = 3
        elif facingd == 'L':
            actiond = 2
        else:
            print('2')

        if one_timed:
            frame_ad = 0
            one_timed = False
            one_time_2d = True
            punch_timed = current_timed
        if current_timed- punch_timed >= 400:
            was_punch_D = False

            punch_time = current_timed
    elif was_punch_D == False:

        if facingd == 'L':

            actiond = 1
        elif facingd == 'R':
            actiond = 0

        if one_time_2d:
            one_timed = True
            one_time_2d = False
            frame_ad = 0


    else:

        if facingd == 'L':
            action = 0
        if facingd == 'R':
            action = 1

    if health1 <= 0:
        p2_win = True
    if health2 <= 0:
        p1_win = True
    if game_sstart:
        screen.fill((0,0,0))

        screen.blit(bg.image, bg.rect)
        screen.blit(animation_list[action][frame_a], (p1.x, p1.y))
        screen.blit(animation_listd[actiond][frame_ad], (p2.x, p2.y))
    #screen.blit(p1.image, p1.rect)
    #screen.blit(p2.image, p2.rect)
        screen.blit(p1_health, (200,100))
        screen.blit(p2_health, (1000,100))
        screen.blit(p1_energy, (200, 200))
        screen.blit(p2_energy, (1000, 200))
        if p1_win:
            screen.blit(win_message, (500,500))
        if p2_win:
            screen.blit(win_messageD, (500,500))
    else:
        screen.blit(bg.image,bg.rect)
        screen.blit(welcome,(0,500))
    pygame.display.update()
    frame += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()

