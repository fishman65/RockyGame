import pygame
class Creed1:
    def __init__(self,x,y):
        self.x = x
        self.y = y
