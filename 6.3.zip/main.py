import time

import pygame
import random

import spritesheet
from player import Player1
from bg import Background
from creed1 import Creed1
from spritesheet import Spritesheet
# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial',20)

size = (1600, 960)
screen = pygame.display.set_mode(size)
p1 = Player1(200,200,20)
bg = Background(0,0)
p2 = Creed1(200,200,20)
time_a = time.time()
sprite_sheet_image = pygame.image.load('spirte.png').convert_alpha()
sprite_sheet = spritesheet.Spritesheet(sprite_sheet_image)
black = (0,0,0)

#animation list
animation_list = []
animation_steps = 18
last_update = pygame.time.get_ticks()
animation_cooldown = 50
frame_a = 0
for i in range(animation_steps):
    animation_list.append(sprite_sheet.get_image(i, 64, 64, black))

# render the text for later
p1_health = my_font.render(str(p1.energy),True,(255,255,255))
p2_health = my_font.render(str(p2.energy),True,(255,255,255))
was_punch = False
was_punch_C = False
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
# -------- Main Program Loop -----------
clock = pygame.time.Clock()
frame = 0
while run:
    clock.tick(60)
    if frame % 120 == 0:
        p1.energy += 1
        p2.energy += 1
        p1_health = my_font.render(str(p1.energy), True, (255, 255, 255))
        p2_health = my_font.render(str(p2.energy), True, (255, 255, 255))
    # --- Main event loop

    keys = pygame.key.get_pressed()
    time_b = time.time()
    if keys[pygame.K_SPACE]:
        was_punch = True
        print(p1.energy)
    if keys[pygame.K_q]:
        was_punch_C = True
    if keys[pygame.K_LEFT]:
        p1.move('L')

    if keys[pygame.K_RIGHT]:
        p1.move('R')
    if keys[pygame.K_UP]:
        p1.move('U')

    if keys[pygame.K_DOWN]:
        p1.move('D')

    if keys[pygame.K_w]:
        p2.move('U')

    if keys[pygame.K_s]:
        p2.move('D')

    if keys[pygame.K_a]:
        p2.move('L')

    if keys[pygame.K_d]:
        p2.move('R')
        # switch the player image and record the time the image was switched
    current_time_2 = pygame.time.get_ticks()
    if frame % 30 != 0 and was_punch:
        p1.do_punch(10, True)
        new_time = pygame.time.get_ticks()
    elif was_punch and current_time_2 - new_time >= 500:
        p1.do_punch(10,False)
        p1.energy -= 1
        p1_health = my_font.render(str(p1.energy), True, (255, 255, 255))
        print('kanye')
        was_punch = False
        cool_down = pygame.time.get_ticks()
    if frame % 30 != 0 and was_punch_C:
        p2.do_punch(10, True)
    elif was_punch_C and frame % 30 == 0:
        p2.do_punch(10,False)
        p2.energy -= 1
        p2_health = my_font.render(str(p2.energy), True, (255, 255, 255))

        print('heloo')
        was_punch_C = False

    # two seconds after the time was recorded, switch the image back

    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False
    #update animation

    current_time = pygame.time.get_ticks()
    if current_time - last_update >= animation_cooldown:
        frame_a += 1
        last_update = current_time
        if frame_a >= len(animation_list):
            frame_a= 0
    screen.fill((0,0,0))
    screen.blit(animation_list[frame_a],(0,0))
    screen.blit(bg.image, bg.rect)
    screen.blit(p1.image, p1.rect)
    screen.blit(p2.image, p2.rect)
    screen.blit(p1_health, (100,100))
    screen.blit(p2_health, (500,200))
    pygame.display.update()
    frame += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()

