import time

import pygame
import random
from player import Player1
from bg import Background
from creed1 import Creed1
# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial',20)

size = (1600, 960)
screen = pygame.display.set_mode(size)
p1 = Player1(200,200,20)
bg = Background(0,0)
p2 = Creed1(200,200,20)
time_a = time.time()
sprite_sheet_image = pygame.image.load('spirte.png').convert_alpha()
black = (0,0,0)
def get_image(sheet, frame, width, height,color):
    image = pygame.Surface((width, height)).convert_alpha()
    image.blit(sprite_sheet_image,(0,0), ((frame * height) , 0), (0,0, width, height))
    image = pygame.transform.scale(image, (128,128))
    image.set_colorkey(color)
    return image

frame_0 = get_image(sprite_sheet_image, 0, 64, 64, black)
frame_1 = get_image(sprite_sheet_image, 0.6, 64, 64, black)
# render the text for later
p1_health = my_font.render(str(p1.energy),True,(255,255,255))
p2_health = my_font.render(str(p2.energy),True,(255,255,255))
was_punch = False
was_punch_C = False
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
# -------- Main Program Loop -----------
clock = pygame.time.Clock()
frame = 0
while run:
    clock.tick(60)
    if frame % 120 == 0:
        p1.energy += 1
        p2.energy += 1
        p1_health = my_font.render(str(p1.energy), True, (255, 255, 255))
        p2_health = my_font.render(str(p2.energy), True, (255, 255, 255))
    # --- Main event loop

    keys = pygame.key.get_pressed()
    time_b = time.time()
    if keys[pygame.K_SPACE]:
        was_punch = True
        print(p1.energy)
    if keys[pygame.K_q]:
        was_punch_C = True
    if keys[pygame.K_LEFT]:
        p1.move('L')

    if keys[pygame.K_RIGHT]:
        p1.move('R')
    if keys[pygame.K_UP]:
        p1.move('U')

    if keys[pygame.K_DOWN]:
        p1.move('D')

    if keys[pygame.K_w]:
        p2.move('U')

    if keys[pygame.K_s]:
        p2.move('D')

    if keys[pygame.K_a]:
        p2.move('L')

    if keys[pygame.K_d]:
        p2.move('R')
        # switch the player image and record the time the image was switched

    if frame % 30 != 0 and was_punch:
        p1.do_punch(10, True)
    elif was_punch and frame % 30 == 0:
        p1.do_punch(10,False)
        p1.energy -= 1
        p1_health = my_font.render(str(p1.energy), True, (255, 255, 255))

        was_punch = False
    if frame % 30 != 0 and was_punch_C:
        p2.do_punch(10, True)
    elif was_punch_C and frame % 30 == 0:
        p2.do_punch(10,False)
        p2.energy -= 1
        p2_health = my_font.render(str(p2.energy), True, (255, 255, 255))

        print('heloo')
        was_punch_C = False

    # two seconds after the time was recorded, switch the image back

    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

    screen.fill((0,0,0))

    screen.blit(frame_1, (100, 100))
    screen.blit(bg.image, bg.rect)
    screen.blit(p1.image, p1.rect)
    screen.blit(p2.image, p2.rect)
    screen.blit(p1_health, (100,100))
    screen.blit(p2_health, (500,200))
    pygame.display.update()
    frame += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()

